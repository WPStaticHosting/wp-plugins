<?php
/**
 * Document Settings
 *
 * @package BuddyBoss\Document
 * @since BuddyBoss 1.4.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
