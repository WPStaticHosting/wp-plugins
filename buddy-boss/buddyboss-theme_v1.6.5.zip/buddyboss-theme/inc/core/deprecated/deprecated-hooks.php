<?php
/**
 * Deprecated Hooks of BuddyBoss Theme.
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
