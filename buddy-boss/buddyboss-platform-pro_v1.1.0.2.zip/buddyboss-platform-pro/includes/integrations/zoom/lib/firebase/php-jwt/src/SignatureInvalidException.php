<?php
namespace BuddyBoss\Zoom\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
