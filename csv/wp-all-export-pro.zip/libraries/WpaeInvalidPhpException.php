<?php

class WpaeInvalidPhpException extends Exception
{
}