<?php

$layoutType = GlobalsUC::ADDON_TYPE_LAYOUT_GENERAL;

require "layouts.php";